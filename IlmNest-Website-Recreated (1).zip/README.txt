IlmNest starter website

Open index.html in a browser to preview.
The note cards are examples. Add real notes or PDF links before sharing.
The PDF picker only previews a file on the current device; it does not publish it online.
For GitHub Pages, upload index.html to the ROOT of your repository (not inside the IlmNest folder): Add file > Upload files > select index.html > Commit changes. Then check Settings > Pages and wait a few minutes.

Tagline: A little place for big learning.
