IlmNest website starter

HOW TO OPEN ON YOUR CHROMEBOOK
1. Download and extract IlmNest-Website.zip.
2. Open the extracted folder and click index.html. It should open in Chrome.
3. Use “Upload / Manage” or “Upload Notes” to select a PDF and add it to the page.
4. Search, filter by class/subject, open the PDF, or download it.

IMPORTANT LIMITATION
This is a front-end starter. Uploaded PDFs are available only in the current browser session and are NOT automatically shared online with other students. Demo cards are sample placeholders, not real PDF files.
To make a public website, you need to publish the site using a hosting service and upload PDFs to a shareable online storage location (for example, Google Drive with appropriate link-sharing settings) or configure a proper file-storage backend. Check each PDF for copyright permission before sharing. Do not publish personal student information.
