IlmNest Website

- index.html is the full website in one file (HTML + CSS + JavaScript).
- Open index.html in Chrome to preview it.
- Search, class filters, and subject filters work.
- Note cards are examples only; their buttons are not connected to real PDFs yet.
- To publish on GitHub Pages, upload index.html to the ROOT of your repository and set Pages to branch main, folder /(root).
